﻿using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using VentasAPI.MODELS;

namespace VentasAPI.DATA
{
    public class VentaDbContext : DbContext
    {
        public VentaDbContext(DbContextOptions<VentaDbContext> options) : base(options)
        {
        }

        public DbSet<Cliente> Clientes { get; set; }
        public DbSet<Producto> Productos { get; set; }
        public DbSet<Pedido> Pedidos { get; set; }
        public DbSet<DetallePedido> DetallesPedidos { get; set; }
        public DbSet<Email> Emails{ get; set; }
        public DbSet<ClienteEmail> ClientesEmails { get; set; }

    }
}
