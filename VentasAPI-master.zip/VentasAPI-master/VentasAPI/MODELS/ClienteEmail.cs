﻿namespace VentasAPI.MODELS
{
    public class ClienteEmail
    {
        public int ID { get; set; }
        public int PedidoID { get; set; }
        public int ProductoID { get; set; }
        public Pedido Pedido { get; set; }
        public Producto Producto { get; set; }
    }
}
