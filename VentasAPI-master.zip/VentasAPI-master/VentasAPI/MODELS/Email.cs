﻿namespace VentasAPI.MODELS
{
    public class Email
    {
        public int ID { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
    }
}
