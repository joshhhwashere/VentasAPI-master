﻿namespace VentasAPI.MODELS
{
    public class Pedido
    {
        public int PedidoId { get; set; }
        public DateTime FechaPedido { get; set; }
        public int ClienteId { get; set; }
        public Cliente Cliente { get; set; }
        public string Estado { get; set; }
    }
}
